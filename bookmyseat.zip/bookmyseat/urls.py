from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from users.views import (
    home,
    login_view,
    register,
    profile,
    reset_password,
    logout_view
)


urlpatterns = [

    path(
        'admin/',
        admin.site.urls
    ),

    path(
        '',
        home,
        name='home'
    ),

    path(
        'login/',
        login_view,
        name='login'
    ),

    path(
        'register/',
        register,
        name='register'
    ),

    path(
        'profile/',
        profile,
        name='profile'
    ),

    path(
        'reset-password/',
        reset_password,
        name='reset_password'
    ),

    path(
        'logout/',
        logout_view,
        name='logout'
    ),

    path(
        'movies/',
        include('movies.urls')
    ),
]


if settings.DEBUG:
    urlpatterns += static(
        settings.MEDIA_URL,
        document_root=settings.MEDIA_ROOT
    )